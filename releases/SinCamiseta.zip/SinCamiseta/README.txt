SinCamiseta v1.2 - Sider module for eFootball PES 2021 (PC)
===========================================================
Hides the shirt, collar and sleeves of a player (and, optionally, the shorts) so you can
look at the body in the Edit menu. Made for PES21FX PesEditorRebuilt; works on its own too.

Install
-------
1. Copy  modules\SinCamiseta.lua  into Sider's modules folder
   (Dream Patch: "Dream Patch Sider\modules").
2. Copy  content\sin-camiseta  into Sider's content folder
   (Dream Patch: "Dream Patch Sider\content\sin-camiseta").
3. In sider.ini, under [sider], make sure  lua.enabled = 1  and add:
      lua.module = "SinCamiseta.lua"
   Put it ABOVE other modules that serve kit/body files (the first module that answers wins).

Use (in the game)
-----------------
Open the Sider overlay (Space by default), switch to "SinCamiseta" with [ and ], then:
   1 = everything on/off (shirt + collar + sleeves)
   2 = sleeves only on/off
   3 = shirt + collar only on/off
   4 = shorts on/off (only with the pelvis loaded, see below)
The game keeps the models already loaded: after a change, leave and re-enter the player
(Appearance) so it reloads them.

No shorts (skin pelvis)
-----------------------
The shorts are part of the body package (common_package.fpk) that the game loads once at start-up,
so hiding them needs the alternative package in content\sin-camiseta\sin_short:
- With PES21FX: Insert menu > Body > "No shorts" = "No shorts (pelvis)", Save, restart the game.
- Without PES21FX: create PES21FX\PES21FX.ini in the game folder with a line  x308 = 1
  (the module only reads that line), then restart the game.
With the pelvis loaded the kit shorts are hidden and key 4 shows / hides them live.
The pelvis has no waistband: for the full shorts turn "No shorts" off and restart.

Notes and limits
----------------
- Visual only, for the Edit menu / viewing the body. In matches the inner shirt and high neck
  of some kits can still show (they live inside the body package).
- common_package.fpk in sin_short is the body package of "Global Model Efootball 5.0" with the
  four skin pelvises added. The body skin itself comes from TorsoBody (textures by Marto).
- Free to share; keep this readme and the credits.

Credits
-------
- Module and pelvis: Agustin (PES21FX / PesEditorRebuilt).
- Body textures: Marto (TorsoBody).  Base body package: Global Model Efootball 5.0.
