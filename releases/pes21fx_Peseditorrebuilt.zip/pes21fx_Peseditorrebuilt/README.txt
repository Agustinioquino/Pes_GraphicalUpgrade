PES21FX PesEditorRebuilt - graphics mod for eFootball PES 2021 (PC, DirectX 11)
Shared release of 27/10/2026 - WITHOUT the cloth physics
==============================================================================

What it includes
----------------
- Grass: per-blade 3D grass near the camera, density that adapts to your FPS, natural colour,
  line paint on the blades, dew, live pitch wear and ball trail.
- Sun and light: sun that no longer rotates with the camera, soft shadows, accumulated light bounce,
  sky light, sun shafts, physical atmosphere, time-of-day curve.
- Skin: SSS (light passing through the skin), real-scale pores, head shadow, unified arm and torso
  tone, neck without a colour band.
- Body and musculature: muscles that grow/shrink and get defined, heavy / athletic variants,
  shoulders, veins, realistic TorsoBody body skin, torso that doesn't poke through the shirt.
- Physique menu in Edit mode (Edit > Players > Physique > Musculature): per-player values,
  body types, body map; saved in PES21FX\musculatura_jugadores.ini.
- Kits (cloth, wrinkles, numbers), hair, eyes, mouth, sweat, improved TAA (sharper ball and grass
  with a still camera), sharpening, colour and post-processing.
Everything is adjusted live from the on-screen menu (Insert key).

Language: the Insert menu and the Physique (musculature) menu are in Spanish, English and
Portuguese. Use the language selector at the top of the Insert menu (Espanol / English /
Portugues); it is saved instantly (line "language = en" or "language = pt" in [PES21FX] of
PES21FX.ini). The texts are in PES21FX\PES21FX_menu_en.ini and PES21FX\PES21FX_menu_pt.ini.
Portuguese readme: LEIAME.txt.

PES21FX.ini comes with Agustin's values (how he plays it). The mod's factory defaults are in
PES21FX\PES21FX.ini.por_defecto: to use them, rename it to PES21FX.ini. musculatura_jugadores.ini has
the musculature Agustin tuned for some players (delete it if you don't want it).

It does NOT include the cloth physics (cloth-mod). If you already have it installed it keeps working
on its own; this mod doesn't touch it (cloth options are off and out of the menu).

Requirements
------------
- PES 2021 from Steam (unmodified PES2021.exe). Tested with Dream Patch 2021 + Sider 7.3.3.
- DirectX 11 graphics card. Tested on an RTX 4060 (8 GB).
- For the body, musculature, body skin and arms: the Sider livecpk mods "Global Model Efootball 5.0"
  and "TorsoBody" (not included, get them from their authors), listed in sider.ini in this order:
      cpk.root = ".\livecpk\Global Model Efootball 5.0"   (or / o "PES21FX Body Model")
      cpk.root = ".\livecpk\TorsoBody"
  The body meshes (common_package.fpk) and body textures the mod was tuned on come from there.
  Without them everything else (grass, light, skin, kits, post-processing, menus) works the same;
  the body/musculature parts look different or do nothing.
  Optional: pes21fx_Peseditorrebuilt_cuerpo.zip (body pack) brings both folders ready, the first one
  renamed "PES21FX Body Model" (see its README_body.txt).

Installation
------------
1. With the game closed, copy into the game folder (where PES2021.exe is):
      d3d11.dll
      the PES21FX folder
2. If you already have a d3d11.dll there (3DMigoto or another mod), rename it first, e.g. to
   d3d11.dll.off. ReShade installed as dxgi.dll can coexist.
3. Start the game. The first time takes a few seconds longer (it compiles the shaders and stores them
   in PES21FX\shaders\cache; after that it starts normally).
4. If something doesn't show, check PES21FX\PES21FX.log ("ERROR compilando" = a shader didn't compile).

Usage
-----
- Insert: opens/closes the menu. Tabs by area (Lighting, Shadows, Skin, Face, Body, Sweat, Hair,
  Kits, Pitch and sky, Colour, Post-processing). The (?) explains each option.
  Ctrl+click on a slider to type an exact value.
- "Save" stores your values in PES21FX\PES21FX.ini.
- "View original" shows the game without the mod to compare.
- If FPS are too low: Pitch and sky -> "Grass over the whole pitch": Target FPS (adaptive density)
  or lower Quality / Density.

Sider modules (sider folder of the zip)
---------------------------------------
Copy the contents of sider\modules into Sider's modules folder and sider\content into Sider's content
folder (in Dream Patch: "Dream Patch Sider\modules" and "Dream Patch Sider\content"), then add these
lines to sider.ini under [sider] (lua.enabled = 1 must be on):
      lua.module = "PES21FX_match.lua"
      lua.module = "SinCamiseta.lua"
      lua.module = "TorsoBody_cuello.lua"
- PES21FX_match.lua: tells the mod which stadium and conditions you play in (per-stadium presets, the
  "Presets" tab). Without it the mod works, but there is no match data.
- SinCamiseta.lua: for the Edit menu, hides the shirt and sleeves (Sider overlay: key 1 = all, 2 = sleeves, 3 = shirt, 4 = shorts) to look at
  the body and musculature. "Body > No shorts" in the Insert menu puts the skin pelvis in place of the
  shorts; it uses sider\content\sin-camiseta (vacio.fmdl and sin_short\common_package.fpk). Needs the
  body pack (TorsoBody / "PES21FX Body Model").
- TorsoBody_cuello.lua: on real faces, cuts the piece of neck that sinks under the TorsoBody torso and
  blends its colour, so the neck doesn't show a cut or a colour band. Only useful with the body pack.

Per-stadium presets (optional)
------------------------------
- "Presets" tab: saves the values for the current stadium in PES21FX\presets\stadium_<id>.ini.
  Needs the PES21FX_match.lua module (see above).
- To share a preset, pass that .ini; whoever receives it copies it into their PES21FX\presets.

Uninstall
---------
With the game closed: delete d3d11.dll and the PES21FX folder from the game folder (and, if you added
them, the three modules in Sider's modules folder, content\sin-camiseta and their lua.module lines in
sider.ini). If you renamed another d3d11.dll, give it back its name. Dream Patch and Sider are not touched.

Credits
-------
- PES21FX / PesEditorRebuilt: Agustin.
- Marto: some of the skin textures and the torso textures (TorsoBody) used by the body, skin and
  musculature. TorsoBody itself is not included; get it from its author.
- sider\content\sin-camiseta\sin_short\common_package.fpk is the body package of "Global Model Efootball
  5.0" with the four skin pelvises added; the rest of that mod is not included.
